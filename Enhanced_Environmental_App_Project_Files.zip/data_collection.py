
import random
import datetime

# Function to simulate collecting environmental data
def collect_environmental_data():
    # Simulated data collection from environmental sensors
    air_quality_index = random.randint(0, 500)  # Simulate AQI
    water_ph_level = round(random.uniform(6.5, 8.5), 2)  # Simulate water pH level
    temperature = round(random.uniform(20, 35), 1)  # Simulate temperature in Celsius
    humidity = random.randint(30, 90)  # Simulate humidity percentage
    timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    
    return {
        'timestamp': timestamp,
        'air_quality_index': air_quality_index,
        'water_ph_level': water_ph_level,
        'temperature': temperature,
        'humidity': humidity
    }

if __name__ == '__main__':
    data = collect_environmental_data()
    print(f"Environmental Data Collected at {data['timestamp']}:
"
          f"Air Quality Index: {data['air_quality_index']}
"
          f"Water pH Level: {data['water_ph_level']}
"
          f"Temperature: {data['temperature']}°C
"
          f"Humidity: {data['humidity']}%")
